import sys
import os
from termcolor import colored, cprint
import time 

i = int(0)
z = int(0)
array_a = []

for i in range(0, 255):
    a = input("immetti valore: ")
    array_a.insert(i, a)
    print(array_a)
    time.sleep(0.5)
    if a == "nonnt" :
        while z <= 2:
            print(colored('AFAMMOKK A KTM, CIÀ!','red'))
            time.sleep(0.2)
            os.system('clear')
            time.sleep(0.1)
            z = z+0.5
        break



