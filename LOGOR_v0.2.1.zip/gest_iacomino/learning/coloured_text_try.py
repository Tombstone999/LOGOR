import sys
import os
from termcolor import colored, cprint
import time 

i = 0.0

while(i <= 10.0):

    text = colored('Hello, World!', 'red')
    print(text)
    time.sleep(0.25)
    os.system('cls' if os.name == 'nt' else 'clear')

    text = colored('Hello, World!', 'yellow')
    print(text)
    time.sleep(0.25)
    os.system('cls' if os.name == 'nt' else 'clear')
    
    text = colored('Hello, World!', 'green')
    print(text)
    time.sleep(0.25)
    os.system('cls' if os.name == 'nt' else 'clear')
    i = i+0.1
