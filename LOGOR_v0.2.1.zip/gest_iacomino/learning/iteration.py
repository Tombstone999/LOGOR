import time 
import os 
import sys

for a in range(0, 10, 1):
    a = a+1
    print(a)
    time.sleep(1)
    os.system('clear')

for a in range(0, 10, 1):
    a = a-1
    print(a)
    time.sleep(1)
    os.system('clear')