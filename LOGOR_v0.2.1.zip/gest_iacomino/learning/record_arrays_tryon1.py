'''
R. Esposito
algoritmo funzionante
timestamp: giovedì, 26 gennaio 2023 - 19.46

'''

from dataclasses import dataclass
@dataclass

class grower():
    growerID:int
    name:str
    prod:str

grower1 = grower(1, "Iacomino", "Mathiola")

print("** Grower n.", grower1.growerID, " successful selected **\n")
print(grower1)