from dataclasses import dataclass
@dataclass

class grower():
    growerID:int
    name:str
    prod:str
    len:str

R_LEN = int(32)

classArray = [grower(x+1, "", "", "") for x in range(R_LEN)]
classArray[0] = grower(1, "Esposito", "anemone", "red, white, blue, shocking, etc.")

print(classArray)
print(classArray[0])

print(classArray[0].name, "is the n.", classArray[0].growerID, "in the grower list!\n")

print("Reading grower_list.txt ...\n")

with open("/home/scarecrow03/Desktop/gest_iacomino/grower_list.txt", 'r') as f:
    f.seek(0)
    for x in range(R_LEN):
        #classArray[x].growerID = f.readline()
        classArray[x].name = f.readline()
        classArray[x].prod = f.readline()
        classArray[x].len = f.readline()
        null_line = f.readline()
        print("**Grower n.", x, "successfull addedd!\n**")
        #print(classArray[x],"\n")

print(classArray[18])

    