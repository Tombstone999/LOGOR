def main():
    count = []

    with open ("/home/scarecrow03/Desktop/gest_iacomino/label_report.txt", 'a+') as f:
        chk_data = f.readlines()
        if(chk_data != "SOF"):
            f.write("SOF")
            print(f.read())
        else:
            count = int(chk_data)
            print(chk_data)

    if(count < chk_data): 
        with open("/home/scarecrow03/Desktop/gest_iacomino/label_report.txt'", "w") as f:
            count += 1
            f.writelines(str(count) + "\n")
        
if __name__ == "__main__":
    main()